import { Injectable } from '@nestjs/common';
import { TaskRepository } from './task-repository';

@Injectable()
export class TaskService {
  constructor(
    private readonly userRepository: TaskRepository) { }

  async find(username: string): Promise<any> {
    

  }
  

}

